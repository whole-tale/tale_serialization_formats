# jupyter-yt
A base jupyter image with yt preinstalled

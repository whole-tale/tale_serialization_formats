define(['base/js/namespace'], function(Jupyter){
    Jupyter._target = '_self';
});
